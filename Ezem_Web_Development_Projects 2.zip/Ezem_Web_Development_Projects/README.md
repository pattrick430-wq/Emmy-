# Ezem Emmanuel Onuoha — Web Development Projects

1. Personal Portfolio Website
2. To-Do List Web Application
3. Weather App
4. Simple E-Commerce Website

Open each project's `index.html` in a browser. The Weather App needs internet access because it uses the public Open-Meteo API for live weather data.
